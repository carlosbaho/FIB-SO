#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>



int contador = 0;


void funcion_alarma(int s)
{
	char buff[256];	
	if(s == SIGUSR1) {
		contador = 0;
		signal(SIGUSR1,SIG_DFL);
	}
	else if (s == SIGUSR2) {
        sprintf(buff, "El contador porta %d\n",contador);
        write(1, buff, strlen(buff));
        signal(SIGUSR2,SIG_DFL);
    }
    else if (s == SIGALRM) {
		contador ++;
	}
	alarm(1);
}


int main(int argc,char *argv[])
{	
	signal(SIGUSR1,funcion_alarma);
	signal(SIGUSR2,funcion_alarma);
	signal(SIGALRM,funcion_alarma);
	alarm(1);
	while(1);
	exit(1);	
}

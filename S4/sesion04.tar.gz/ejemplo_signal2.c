#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>

void func(int s) {
	int n, r;
	n =  waitpid(-1,&r,WNOHANG);  
	char buff[80];
	
	if (WIFEXITED(r) != 0 ) {
            sprintf(buff,"Termina el proceso %d con un exit. Exit status:%d \n",n, WEXITSTATUS(r));
            write(1, buff, strlen(buff));
        }
	else {
            sprintf(buff,"Termina el proceso %d con un signal. Signal code:%d \n",n, WIFSIGNALED(r));
            write(1, buff, strlen(buff));
        }

}

void trata_alarma() {

}

int main(int argc,char *argv[])
{
	int pid,res;
	char buff[256];		
	int contador = 0;
	int hijos=0;
	for (hijos=0;hijos<10;hijos++)
	{
		sprintf(buff, "Creando el hijo numero %d\n", hijos);
		write(1, buff, strlen(buff)); 
		
		pid=fork();
		if (pid==0) /* Esta linea la ejecutan tanto el padre como el hijo */
		{
			
			signal (SIGALRM, trata_alarma);
			/* Escribe aqui el codigo del proceso hijo */
			sprintf(buff,"Hola, soy %d\n",getpid());
			write(1, buff, strlen(buff)); 

			alarm(1); 
			pause();

			/* Termina su ejecución */
			exit(0);
		}else if (pid<0)	
		{
			/* Se ha producido un error */
			perror("Error en el fork");
		}
	}
	/* Ya se han creado todos los hijos */
	
	signal(SIGCHLD, func);
	while (hijos > 0)
	{
		hijos --;
		contador++;

	}
	sprintf(buff,"Valor del contador %d\n", contador);
	write(1, buff, strlen(buff)); 
	
	while(1); // para recibir los mensajes de finalización de los hijos (func).
	return 0;
}

#include "mis_funciones.h"

#define MAX_SIZE 8


void Usage() {
	printf("Usage: suma arg1 arg2 [..argn]\nEste programa escribe por su salida la suma de los argumentos que recibe.\n");
}

unsigned int char2int(char c) {
	return c - '0';
}

int mi_atoi(char *s) {
	int j = 0;
	int res = 0;
	int negatiu = 0;
	if (s[j] == '-') {
		negatiu = 1;
		++j;
	}
	while (j < strlen(s)) {
		res += char2int(s[j]);
		if (j != strlen(s)-1) res *= 10;
		++j;
	}
	if (negatiu == 1) res *= -1;
	return res;
}

int esNumero (char *str) {
  int val = 1;
  int j;
  for (j = 0; j < strlen (str) && val == 1; j++) {
      if ((str[j] < '0' || str[j] > '9') && !(j == 0 && str[j] == '-')) val = 0;
  }
  return val;
 }

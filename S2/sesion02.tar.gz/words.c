#include <stdio.h>
#include <string.h>

int main(int argc,char *argv[]) {	
	int palabras = 1;
	int i = 0;
	while (argv[1][i] != '\0') {
		if (argv[1][i] == '\n' || argv[1][i] == ' ' || argv[1][i] == ','
		|| argv[1][i] == '.') ++palabras;
		++i;
	}
	char buf[80];
	sprintf(buf,"%d palabras\n",palabras);
	write(1,buf,strlen(buf));
}

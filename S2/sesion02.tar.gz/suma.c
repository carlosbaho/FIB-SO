#include "mis_funciones.h"

int main (int argc, char *argv[]) {
	if (argc < 3) Usage();
	else {
		char buf[80];
		int suma = 0;
		int stop = 0;
		int i;
		for (i = 1; i < argc && stop == 0; i++) {
			if (esNumero(argv[i])) {
				int num = mi_atoi(argv[i]);
				suma += num;
			}	  
			else {
				stop = 1;
				sprintf(buf,"Error: el parámetro %s no es un número.\n",argv[i]);
			}
		}
		if (stop == 0) {
			sprintf(buf,"La suma es %d\n",suma); 
		}
		write(1,buf,strlen(buf));
	}
}

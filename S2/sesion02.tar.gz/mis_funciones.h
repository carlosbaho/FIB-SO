#include <stdio.h>
#include <string.h>

void Usage();

unsigned int char2int(char c);

int mi_atoi(char *s);

int esNumero (char *str);


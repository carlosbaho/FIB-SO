#include <stdio.h>
#include <string.h>

#define MAX_SIZE 8

int
esNumero (char *str)
{
  int val = 1;
  int j;
  for (j = 0; j < strlen (str) && val == 1; j++)
    {
      if ((str[j] < '0' || str[j] > '9') && !(j == 0 && str[j] == '-'))
	val = 0;
    }
  return val;
}

int
main (int argc, char *argv[])
{
  char buf[80];
  int i;
  for (i = 1; i < argc; i++)
    {
      if (strlen (argv[i]) <= MAX_SIZE && argv[i] != NULL)
	{
	  int sol = esNumero ((char *) argv[i]);
	  if (sol == 1)
	    {
	      sprintf (buf,
		       "El argumento %d, que corresponde a %s, es un entero.\n",
		       i, argv[i]);
	    }
	  else
	    sprintf (buf,
		     "El argumento %d, que corresponde a %s, no es un entero.\n",
		     i, argv[i]);
	}
      else
	{
	  sprintf (buf, "0\n");
	}
      write (1, buf, strlen (buf));
    }
}
